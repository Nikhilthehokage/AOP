/* *******************************************************************
 * Copyright (c) 2008 Contributors
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/epl-v10.html 
 *  
 * ******************************************************************/
package org.aspectj.weaver;

/**
 * History: 246125
 * 
 * @author Andy Clement
 */
public interface IUnwovenClassFile {

	String getFilename();

	String getClassName();

	byte[] getBytes();

	char[] getClassNameAsChars();

}
