/* *******************************************************************
 * Copyright (c) 2010 Contributors
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/epl-v10.html 
 *  
 * Contributors: 
 * Andy Clement, SpringSource
 * ******************************************************************/
package org.aspectj.weaver;

/**
 * Common utility methods for members.
 * 
 * @author Andy Clement
 */
public class MemberUtils {

	public static boolean isConstructor(ResolvedMember member) {
		return member.getName().equals("<init>");
	}

}
